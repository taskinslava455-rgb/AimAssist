package com.example.aimassist;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("aimassist.json");

    private static class Data {
        boolean enabled = false;
        double fov = 90.0;
        double speed = 0.18;
        double range = 50.0;
        int menuKey = 345; // GLFW_KEY_RIGHT_CONTROL
    }

    private Config() {}

    public static void load() {
        try {
            if (!Files.exists(FILE)) {
                save();
                return;
            }
            Data d = GSON.fromJson(Files.readString(FILE), Data.class);
            if (d == null) return;
            AimAssistClient.enabled = d.enabled;
            AimAssistClient.fov = clamp(d.fov, 10, 180);
            AimAssistClient.speed = clamp(d.speed, 0.01, 1.0);
            AimAssistClient.range = clamp(d.range, 3, 100);
            AimAssistClient.menuKeyCode = d.menuKey;
            if (AimAssistClient.menuKey != null) {
                AimAssistClient.menuKey.setBoundKey(net.minecraft.client.util.InputUtil.Type.KEYSYM.createFromCode(d.menuKey));
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = AimAssistClient.enabled;
            d.fov = AimAssistClient.fov;
            d.speed = AimAssistClient.speed;
            d.range = AimAssistClient.range;
            d.menuKey = AimAssistClient.menuKeyCode;
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
