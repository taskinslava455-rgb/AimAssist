AIM ASSIST - Fabric 1.21.11

Android / Termux:
1. Install Termux from a trusted source.
2. Install Java 21 and Gradle (package names can vary by Termux repository):
   pkg update
   pkg install openjdk-21 gradle unzip
3. Unzip this project.
4. cd into the project folder.
5. Run:
   gradle build
6. The finished mod will be:
   build/libs/aimassist-1.0.0.jar

Put that JAR into the Minecraft mods folder used by your Fabric 1.21.11 installation.

The mod is client-side. Default menu key: Right Ctrl.
The menu lets you change Aim Assist, FOV, speed, range, and the menu key.
