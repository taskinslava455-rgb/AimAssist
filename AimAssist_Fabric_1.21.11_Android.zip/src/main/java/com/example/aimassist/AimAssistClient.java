package com.example.aimassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AimAssistClient implements ClientModInitializer {
    public static final String MOD_ID = "aimassist";

    public static KeyBinding menuKey;
    public static KeyBinding toggleKey;

    public static boolean enabled = false;
    public static double fov = 90.0;
    public static double speed = 0.18;
    public static double range = 50.0;

    private static PlayerEntity target;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aimassist.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_CONTROL,
                "category.aimassist"
        ));

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aimassist.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.aimassist"
        ));

        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new AimAssistScreen());
                }
            }

            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("Aim Assist: " + (enabled ? "ON" : "OFF")), true);
                }
            }

            if (enabled && client.currentScreen == null) {
                AimController.tick(client);
            }
        });
    }

    public static PlayerEntity getTarget() {
        return target;
    }

    public static void setTarget(PlayerEntity p) {
        target = p;
    }

    public static void save() {
        Config.save();
    }
}
