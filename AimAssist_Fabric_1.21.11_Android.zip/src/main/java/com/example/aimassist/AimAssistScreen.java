package com.example.aimassist;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AimAssistScreen extends Screen {
    private SliderWidget fovSlider;
    private SliderWidget speedSlider;
    private SliderWidget rangeSlider;
    private ButtonWidget enabledButton;
    private ButtonWidget keyButton;
    private boolean waitingForKey = false;

    public AimAssistScreen() {
        super(Text.literal("Aim Assist"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 90;

        enabledButton = ButtonWidget.builder(labelEnabled(), b -> {
            AimAssistClient.enabled = !AimAssistClient.enabled;
            b.setMessage(labelEnabled());
            AimAssistClient.save();
        }).dimensions(cx - 120, y, 240, 24).build();
        addDrawableChild(enabledButton);

        fovSlider = new SimpleSlider(cx - 120, y + 32, 240, 20,
                Text.literal("FOV: " + (int) AimAssistClient.fov),
                AimAssistClient.fov / 180.0, 10, 180);
        addDrawableChild(fovSlider);

        speedSlider = new SimpleSlider(cx - 120, y + 58, 240, 20,
                Text.literal("Speed: " + String.format("%.2f", AimAssistClient.speed)),
                AimAssistClient.speed, 0.01, 1.0);
        addDrawableChild(speedSlider);

        rangeSlider = new SimpleSlider(cx - 120, y + 84, 240, 20,
                Text.literal("Range: " + (int) AimAssistClient.range),
                (AimAssistClient.range - 3.0) / 97.0, 3, 100);
        addDrawableChild(rangeSlider);

        keyButton = ButtonWidget.builder(keyText(), b -> {
            waitingForKey = true;
            b.setMessage(Text.literal("Press a key..."));
        }).dimensions(cx - 120, y + 112, 240, 24).build();
        addDrawableChild(keyButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - 120, y + 144, 240, 24).build());
    }

    private Text labelEnabled() {
        return Text.literal("Aim Assist: " + (AimAssistClient.enabled ? "ON" : "OFF"));
    }

    private Text keyText() {
        return Text.literal("Menu key: " + InputUtil.fromKeyCode(
                AimAssistClient.menuKey.getBoundKey().getCode(), 0).getLocalizedText().getString());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (waitingForKey) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                waitingForKey = false;
                keyButton.setMessage(keyText());
                return true;
            }
            AimAssistClient.menuKey.setBoundKey(InputUtil.Type.KEYSYM.createFromCode(keyCode));
            waitingForKey = false;
            keyButton.setMessage(keyText());
            AimAssistClient.save();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        AimAssistClient.save();
        if (this.client != null) this.client.setScreen(null);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, this.height / 2 - 122, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Smooth player targeting"), cx, this.height / 2 - 106, 0xA0A0A0);
        super.render(context, mouseX, mouseY, delta);
    }

    private static class SimpleSlider extends SliderWidget {
        private final Text prefix;
        private final double min;
        private final double max;

        SimpleSlider(int x, int y, int width, int height, Text prefix, double normalized, double min, double max) {
            super(x, y, width, height, prefix, normalized);
            this.prefix = prefix;
            this.min = min;
            this.max = max;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            double v = min + (max - min) * this.value;
            if (max == 180) {
                this.setMessage(Text.literal("FOV: " + (int) v + "°"));
            } else if (max == 100) {
                this.setMessage(Text.literal("Range: " + (int) v + " blocks"));
            } else {
                this.setMessage(Text.literal("Speed: " + String.format("%.2f", v)));
            }
        }

        @Override
        protected void applyValue() {
            double v = min + (max - min) * this.value;
            if (max == 180) AimAssistClient.fov = v;
            else if (max == 100) AimAssistClient.range = v;
            else AimAssistClient.speed = v;
            AimAssistClient.save();
        }
    }
}
