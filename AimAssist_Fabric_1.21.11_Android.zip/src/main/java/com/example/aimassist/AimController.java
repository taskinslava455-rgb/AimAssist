package com.example.aimassist;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class AimController {
    private AimController() {}

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity self = client.player;
        if (self == null || client.world == null) return;

        PlayerEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        Vec3d eye = self.getEyePos();
        Vec3d look = self.getRotationVec(1.0f);

        for (PlayerEntity p : client.world.getPlayers()) {
            if (p == self || !p.isAlive() || p.isSpectator()) continue;
            double distance = self.distanceTo(p);
            if (distance > AimAssistClient.range) continue;

            Vec3d to = p.getEyePos().subtract(eye);
            if (to.lengthSquared() < 0.0001) continue;

            Vec3d dir = to.normalize();
            double dot = Math.max(-1.0, Math.min(1.0, look.dotProduct(dir)));
            double angle = Math.toDegrees(Math.acos(dot));

            if (angle <= AimAssistClient.fov * 0.5 && angle < bestAngle) {
                bestAngle = angle;
                best = p;
            }
        }

        AimAssistClient.setTarget(best);
        if (best == null) return;

        Vec3d delta = best.getEyePos().subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float wantedYaw = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float wantedPitch = (float)(-Math.toDegrees(Math.atan2(delta.y, horizontal)));

        float yaw = approachAngle(self.getYaw(), wantedYaw, (float)(AimAssistClient.speed * 12.0));
        float pitch = approach(self.getPitch(), wantedPitch, (float)(AimAssistClient.speed * 8.0));

        self.setYaw(yaw);
        self.setPitch(Math.max(-90.0f, Math.min(90.0f, pitch)));
    }

    private static float approach(float current, float target, float amount) {
        float d = target - current;
        if (Math.abs(d) <= amount) return target;
        return current + Math.copySign(amount, d);
    }

    private static float approachAngle(float current, float target, float amount) {
        float d = wrapDegrees(target - current);
        if (Math.abs(d) <= amount) return target;
        return current + Math.copySign(amount, d);
    }

    private static float wrapDegrees(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }
}
